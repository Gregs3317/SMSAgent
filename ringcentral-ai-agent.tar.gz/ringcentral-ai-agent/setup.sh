#!/bin/bash

echo "🚀 RingCentral AI SMS Agent - Quick Setup"
echo "========================================"
echo ""

# Check if Node.js is installed
if ! command -v node &> /dev/null; then
    echo "❌ Node.js is not installed. Please install Node.js v16 or higher."
    echo "   Download from: https://nodejs.org"
    exit 1
fi

echo "✅ Node.js version: $(node --version)"
echo ""

# Check if .env exists
if [ ! -f .env ]; then
    echo "📝 Creating .env file from template..."
    cp .env.example .env
    echo "✅ .env file created"
    echo ""
    echo "⚠️  IMPORTANT: Edit .env file and add your credentials:"
    echo "   - RingCentral Client ID, Secret, JWT Token"
    echo "   - Anthropic API Key"
    echo "   - Your RingCentral phone number"
    echo "   - Webhook URL (use ngrok for local development)"
    echo ""
else
    echo "✅ .env file already exists"
    echo ""
fi

# Install dependencies
echo "📦 Installing dependencies..."
npm install

if [ $? -eq 0 ]; then
    echo "✅ Dependencies installed successfully"
    echo ""
else
    echo "❌ Failed to install dependencies"
    exit 1
fi

echo "🎉 Setup complete!"
echo ""
echo "Next steps:"
echo "1. Edit .env file with your credentials"
echo "2. For local development, start ngrok: ngrok http 3000"
echo "3. Copy ngrok URL to WEBHOOK_URL in .env"
echo "4. Start the server: npm start"
echo "5. Open dashboard: http://localhost:3000"
echo ""
echo "Need help? Read README.md for detailed instructions"
