# Production Deployment Guide

This guide will help you deploy the RingCentral AI SMS Agent to a production server.

## Option 1: Deploy to DigitalOcean (Recommended for beginners)

### Step 1: Create a Droplet

1. Sign up at https://digitalocean.com
2. Create a new Droplet:
   - **Image**: Ubuntu 22.04 LTS
   - **Plan**: Basic ($6/month is sufficient)
   - **Datacenter**: Choose closest to your location
   - **Authentication**: SSH keys (recommended) or password
3. Note your droplet's IP address

### Step 2: Connect to Server

```bash
ssh root@your_server_ip
```

### Step 3: Install Node.js

```bash
# Update system
apt update && apt upgrade -y

# Install Node.js 18.x
curl -fsSL https://deb.nodesource.com/setup_18.x | bash -
apt install -y nodejs

# Verify installation
node --version
npm --version
```

### Step 4: Install PM2

```bash
npm install -g pm2
```

### Step 5: Clone Your Application

```bash
cd /var/www
mkdir ringcentral-agent
cd ringcentral-agent

# Upload your files via scp or git
# From your local machine:
# scp -r ringcentral-ai-agent/* root@your_server_ip:/var/www/ringcentral-agent/
```

### Step 6: Install Dependencies

```bash
npm install
```

### Step 7: Configure Environment

```bash
nano .env
```

Add your credentials and set:
```env
RINGCENTRAL_SERVER_URL=https://platform.ringcentral.com
WEBHOOK_URL=https://your_domain.com/webhook/sms
PORT=3000
```

### Step 8: Set Up Domain and SSL

#### Install Nginx

```bash
apt install -y nginx
```

#### Configure Nginx

```bash
nano /etc/nginx/sites-available/ringcentral-agent
```

Add:
```nginx
server {
    listen 80;
    server_name your_domain.com;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
```

Enable the site:
```bash
ln -s /etc/nginx/sites-available/ringcentral-agent /etc/nginx/sites-enabled/
nginx -t
systemctl restart nginx
```

#### Install SSL Certificate (Let's Encrypt)

```bash
apt install -y certbot python3-certbot-nginx
certbot --nginx -d your_domain.com
```

### Step 9: Start the Application

```bash
pm2 start server.js --name "sms-agent"
pm2 startup
pm2 save
```

### Step 10: Monitor

```bash
# View logs
pm2 logs sms-agent

# Check status
pm2 status

# Monitor CPU/Memory
pm2 monit
```

Your application is now running at https://your_domain.com! 🎉

---

## Option 2: Deploy to AWS EC2

### Step 1: Launch EC2 Instance

1. Go to AWS EC2 Console
2. Launch Instance:
   - **AMI**: Ubuntu Server 22.04 LTS
   - **Instance Type**: t2.micro (free tier) or t2.small
   - **Security Group**: 
     - Allow SSH (port 22)
     - Allow HTTP (port 80)
     - Allow HTTPS (port 443)

### Step 2: Connect and Setup

```bash
ssh -i your-key.pem ubuntu@your-ec2-public-ip
```

Follow Steps 3-10 from DigitalOcean guide above.

### Step 3: Configure Elastic IP (Recommended)

1. Allocate Elastic IP in AWS Console
2. Associate with your instance
3. Update DNS records to point to Elastic IP

---

## Option 3: Deploy to Heroku

### Step 1: Install Heroku CLI

```bash
# macOS
brew install heroku/brew/heroku

# Other OS: https://devcenter.heroku.com/articles/heroku-cli
```

### Step 2: Prepare Application

Create `Procfile`:
```
web: node server.js
```

Update `package.json`:
```json
{
  "engines": {
    "node": "18.x"
  }
}
```

### Step 3: Deploy

```bash
# Login
heroku login

# Create app
heroku create your-app-name

# Set environment variables
heroku config:set RINGCENTRAL_CLIENT_ID=your_id
heroku config:set RINGCENTRAL_CLIENT_SECRET=your_secret
heroku config:set RINGCENTRAL_JWT_TOKEN=your_token
heroku config:set RINGCENTRAL_FROM_NUMBER=+1234567890
heroku config:set RINGCENTRAL_SERVER_URL=https://platform.ringcentral.com
heroku config:set ANTHROPIC_API_KEY=your_key
heroku config:set AGENT_NAME="Sarah Johnson"
heroku config:set WEBHOOK_URL=https://your-app-name.herokuapp.com/webhook/sms
heroku config:set INITIAL_MESSAGE="Hi {name}! This is {agent}..."

# Deploy
git add .
git commit -m "Deploy to Heroku"
git push heroku main

# Open app
heroku open
```

---

## Option 4: Deploy with Docker

### Step 1: Create Dockerfile

```dockerfile
FROM node:18-alpine

WORKDIR /app

COPY package*.json ./
RUN npm ci --only=production

COPY . .

EXPOSE 3000

CMD ["node", "server.js"]
```

### Step 2: Create docker-compose.yml

```yaml
version: '3.8'

services:
  sms-agent:
    build: .
    ports:
      - "3000:3000"
    env_file:
      - .env
    restart: unless-stopped
    volumes:
      - ./data:/app/data
```

### Step 3: Deploy

```bash
# Build and start
docker-compose up -d

# View logs
docker-compose logs -f

# Stop
docker-compose down
```

---

## Post-Deployment Checklist

- [ ] Test webhook endpoint: `curl https://your-domain.com/health`
- [ ] Verify RingCentral webhook subscription in developer portal
- [ ] Send test SMS to your RingCentral number
- [ ] Check server logs for any errors
- [ ] Add a test lead via dashboard
- [ ] Verify AI responses are working
- [ ] Set up monitoring/alerts (optional)
- [ ] Configure backups (if using database)
- [ ] Update DNS records if needed
- [ ] Enable firewall (if not done)

---

## Monitoring and Maintenance

### Log Management

```bash
# PM2 logs
pm2 logs --lines 100

# Clear old logs
pm2 flush

# Log rotation
pm2 install pm2-logrotate
```

### Update Application

```bash
# Pull latest code
cd /var/www/ringcentral-agent
git pull

# Install dependencies
npm install

# Restart
pm2 restart sms-agent
```

### Database Backup (if added)

```bash
# MongoDB backup
mongodump --out /backup/$(date +%Y%m%d)

# PostgreSQL backup
pg_dump dbname > backup.sql
```

### Security Hardening

```bash
# Enable UFW firewall
ufw allow 22
ufw allow 80
ufw allow 443
ufw enable

# Auto security updates
apt install unattended-upgrades
dpkg-reconfigure --priority=low unattended-upgrades
```

---

## Troubleshooting

### Webhook Not Working

1. Check webhook URL is publicly accessible:
   ```bash
   curl https://your-domain.com/webhook/sms
   ```

2. Verify RingCentral subscription:
   - Login to RingCentral Developer Portal
   - Check active subscriptions
   - Re-create if needed

3. Check Nginx configuration:
   ```bash
   nginx -t
   systemctl status nginx
   ```

### Application Crashes

```bash
# Check PM2 status
pm2 status

# View error logs
pm2 logs sms-agent --err

# Restart application
pm2 restart sms-agent
```

### High Memory Usage

```bash
# Monitor resources
pm2 monit

# Increase max memory (if needed)
pm2 start server.js --name sms-agent --max-memory-restart 500M
```

---

## Cost Estimates

### DigitalOcean
- Basic Droplet: $6/month
- Domain: $12/year
- Total: ~$84/year

### AWS EC2
- t2.micro (free tier): $0/month (first year)
- t2.small: ~$17/month
- Domain: $12/year
- Total: $0-216/year

### Heroku
- Basic Dyno: $7/month
- Total: $84/year

---

## Next Steps

1. Add database for persistent storage
2. Set up monitoring (Datadog, New Relic)
3. Configure CI/CD pipeline
4. Add automated tests
5. Implement rate limiting
6. Set up staging environment

Need help? Contact support or check the README.md
