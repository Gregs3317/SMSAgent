require('dotenv').config();
const express = require('express');
const bodyParser = require('body-parser');
const SDK = require('@ringcentral/sdk').SDK;
const Anthropic = require('@anthropic-ai/sdk');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));

// Initialize RingCentral SDK
const rcsdk = new SDK({
    server: process.env.RINGCENTRAL_SERVER_URL,
    clientId: process.env.RINGCENTRAL_CLIENT_ID,
    clientSecret: process.env.RINGCENTRAL_CLIENT_SECRET
});

const platform = rcsdk.platform();

// Initialize Anthropic Claude
const anthropic = new Anthropic({
    apiKey: process.env.ANTHROPIC_API_KEY
});

// In-memory storage for conversations (use database in production)
const conversations = new Map();
const stats = {
    totalLeads: 0,
    activeConversations: 0,
    bookedAppointments: 0,
    messagesSent: 0,
    messagesReceived: 0
};

// Authenticate with RingCentral on startup
async function authenticateRingCentral() {
    try {
        await platform.login({ jwt: process.env.RINGCENTRAL_JWT_TOKEN });
        console.log('✅ Authenticated with RingCentral');
        
        // Subscribe to webhook notifications
        await setupWebhookSubscription();
        
        return true;
    } catch (error) {
        console.error('❌ RingCentral authentication failed:', error.message);
        return false;
    }
}

// Setup webhook subscription for incoming SMS
async function setupWebhookSubscription() {
    try {
        const response = await platform.post('/restapi/v1.0/subscription', {
            eventFilters: [
                '/restapi/v1.0/account/~/extension/~/message-store/instant?type=SMS'
            ],
            deliveryMode: {
                transportType: 'WebHook',
                address: process.env.WEBHOOK_URL
            }
        });
        
        const subscription = await response.json();
        console.log('✅ Webhook subscription created:', subscription.id);
        console.log('📞 Listening for SMS at:', process.env.WEBHOOK_URL);
        
        return subscription;
    } catch (error) {
        console.error('❌ Failed to setup webhook:', error.message);
        console.log('💡 Make sure WEBHOOK_URL is publicly accessible (use ngrok for local dev)');
    }
}

// Webhook endpoint to receive SMS notifications
app.post('/webhook/sms', async (req, res) => {
    console.log('📨 Webhook received');
    
    // Verify webhook (RingCentral sends validation header)
    const validationToken = req.get('Validation-Token');
    if (validationToken) {
        res.set('Validation-Token', validationToken);
        return res.status(200).send();
    }

    try {
        const notification = req.body;
        
        // Process each message in the notification
        if (notification.body && notification.body.changes) {
            for (const change of notification.body.changes) {
                if (change.type === 'SMS' && change.direction === 'Inbound') {
                    await handleIncomingSMS(change);
                }
            }
        }
        
        res.status(200).send('OK');
    } catch (error) {
        console.error('Error processing webhook:', error);
        res.status(500).send('Error');
    }
});

// Handle incoming SMS messages
async function handleIncomingSMS(message) {
    const fromNumber = message.from?.phoneNumber || message.from;
    const messageText = message.subject || message.body;
    
    console.log(`📱 Received SMS from ${fromNumber}: ${messageText}`);
    stats.messagesReceived++;
    
    // Get or create conversation
    let conversation = conversations.get(fromNumber);
    
    if (!conversation) {
        // New conversation from unknown number
        conversation = {
            phone: fromNumber,
            name: 'Unknown Lead',
            messages: [],
            status: 'active',
            booked: false,
            createdAt: new Date()
        };
        conversations.set(fromNumber, conversation);
        stats.totalLeads++;
        stats.activeConversations++;
    }
    
    // Add received message to conversation
    conversation.messages.push({
        text: messageText,
        direction: 'received',
        timestamp: new Date()
    });
    
    // Generate and send AI response
    await generateAndSendAIResponse(conversation, messageText);
}

// Generate AI response using Claude
async function generateAndSendAIResponse(conversation, userMessage) {
    try {
        console.log(`🤖 Generating AI response for ${conversation.phone}...`);
        
        // Build conversation history for Claude
        const conversationHistory = conversation.messages
            .filter(m => m.direction !== 'thinking')
            .map(m => ({
                role: m.direction === 'sent' ? 'assistant' : 'user',
                content: m.text
            }));
        
        const systemPrompt = `You are an AI assistant helping to book appointments for the IRS Fresh Start Program. Your goal is to:

1. Build rapport and trust with prospects who inquired about tax relief
2. Answer questions about the IRS Fresh Start Program (offer in compromise, installment agreements, penalty abatement)
3. Qualify leads by understanding their tax situation (amount owed, type of tax debt, financial hardship)
4. Book appointments with ${process.env.AGENT_NAME} to discuss their specific options
5. Keep messages brief and conversational (1-3 sentences max for SMS)

Key points about IRS Fresh Start:
- Helps taxpayers settle tax debt for less than owed through Offer in Compromise
- Offers payment plans (installment agreements) to pay over time
- Penalty abatement can reduce or eliminate penalties
- Requires demonstrating financial hardship or special circumstances
- Free consultation to assess eligibility

BOOKING INSTRUCTIONS:
- When the prospect shows interest in learning more or booking a time, suggest 2-3 specific appointment times in the next few days
- If they agree to a time, confirm the appointment with date, time, and next steps
- When an appointment is confirmed, include the phrase "APPOINTMENT_BOOKED" at the end of your response

QUALIFICATION QUESTIONS to ask naturally in conversation:
- How much do you owe in back taxes?
- What years are the taxes from?
- Have you received any notices from the IRS?
- What's your current financial situation?

Keep responses warm, professional, and SMS-friendly. Use their name if known. You are ${process.env.AGENT_NAME}.`;

        // Call Claude API
        const response = await anthropic.messages.create({
            model: 'claude-sonnet-4-20250514',
            max_tokens: 1000,
            system: systemPrompt,
            messages: conversationHistory
        });
        
        const aiMessage = response.content[0].text;
        const isBooked = aiMessage.includes('APPOINTMENT_BOOKED');
        const cleanMessage = aiMessage.replace('APPOINTMENT_BOOKED', '').trim();
        
        console.log(`💬 AI Response: ${cleanMessage.substring(0, 50)}...`);
        
        // Update conversation status if booked
        if (isBooked && !conversation.booked) {
            conversation.booked = true;
            conversation.status = 'booked';
            stats.bookedAppointments++;
            console.log(`🎉 Appointment booked with ${conversation.phone}!`);
        }
        
        // Add AI response to conversation
        conversation.messages.push({
            text: cleanMessage,
            direction: 'sent',
            timestamp: new Date()
        });
        
        // Send SMS via RingCentral
        await sendSMS(conversation.phone, cleanMessage);
        
    } catch (error) {
        console.error('Error generating AI response:', error);
        
        // Send fallback message
        const fallbackMessage = `Thanks for your message! I'm having a brief technical issue. I'll get back to you shortly. - ${process.env.AGENT_NAME}`;
        await sendSMS(conversation.phone, fallbackMessage);
    }
}

// Send SMS via RingCentral
async function sendSMS(to, text) {
    try {
        const response = await platform.post('/restapi/v1.0/account/~/extension/~/sms', {
            from: { phoneNumber: process.env.RINGCENTRAL_FROM_NUMBER },
            to: [{ phoneNumber: to }],
            text: text
        });
        
        const result = await response.json();
        console.log(`✅ SMS sent to ${to}`);
        stats.messagesSent++;
        
        return result;
    } catch (error) {
        console.error(`❌ Failed to send SMS to ${to}:`, error.message);
        throw error;
    }
}

// API endpoint to add a new lead
app.post('/api/leads', async (req, res) => {
    const { name, phone } = req.body;
    
    if (!name || !phone) {
        return res.status(400).json({ error: 'Name and phone are required' });
    }
    
    try {
        // Check if lead already exists
        if (conversations.has(phone)) {
            return res.status(400).json({ error: 'Lead already exists' });
        }
        
        // Create new conversation
        const conversation = {
            phone: phone,
            name: name,
            messages: [],
            status: 'pending',
            booked: false,
            createdAt: new Date()
        };
        
        conversations.set(phone, conversation);
        stats.totalLeads++;
        stats.activeConversations++;
        
        // Send initial message
        const initialMessage = process.env.INITIAL_MESSAGE
            .replace('{name}', name)
            .replace('{agent}', process.env.AGENT_NAME);
        
        await sendSMS(phone, initialMessage);
        
        conversation.messages.push({
            text: initialMessage,
            direction: 'sent',
            timestamp: new Date()
        });
        
        conversation.status = 'active';
        
        console.log(`✅ New lead added: ${name} (${phone})`);
        
        res.json({
            success: true,
            lead: {
                name: conversation.name,
                phone: conversation.phone,
                status: conversation.status
            }
        });
        
    } catch (error) {
        console.error('Error adding lead:', error);
        res.status(500).json({ error: error.message });
    }
});

// API endpoint to get all conversations
app.get('/api/conversations', (req, res) => {
    const convArray = Array.from(conversations.values()).map(conv => ({
        phone: conv.phone,
        name: conv.name,
        status: conv.status,
        booked: conv.booked,
        messageCount: conv.messages.length,
        lastMessage: conv.messages[conv.messages.length - 1]
    }));
    
    res.json(convArray);
});

// API endpoint to get a specific conversation
app.get('/api/conversations/:phone', (req, res) => {
    const phone = req.params.phone;
    const conversation = conversations.get(phone);
    
    if (!conversation) {
        return res.status(404).json({ error: 'Conversation not found' });
    }
    
    res.json(conversation);
});

// API endpoint to get stats
app.get('/api/stats', (req, res) => {
    res.json(stats);
});

// API endpoint to send manual message
app.post('/api/send', async (req, res) => {
    const { phone, message } = req.body;
    
    if (!phone || !message) {
        return res.status(400).json({ error: 'Phone and message are required' });
    }
    
    try {
        const conversation = conversations.get(phone);
        
        if (!conversation) {
            return res.status(404).json({ error: 'Conversation not found' });
        }
        
        await sendSMS(phone, message);
        
        conversation.messages.push({
            text: message,
            direction: 'sent',
            timestamp: new Date()
        });
        
        res.json({ success: true });
        
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Health check endpoint
app.get('/health', (req, res) => {
    res.json({
        status: 'running',
        ringcentral: platform.loggedIn(),
        stats: stats
    });
});

// Serve the dashboard
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'dashboard.html'));
});

// Start server
async function startServer() {
    console.log('🚀 Starting RingCentral AI SMS Agent...\n');
    
    // Authenticate with RingCentral
    const authenticated = await authenticateRingCentral();
    
    if (!authenticated) {
        console.error('Failed to authenticate with RingCentral. Please check your credentials.');
        process.exit(1);
    }
    
    // Start Express server
    app.listen(PORT, () => {
        console.log(`\n✅ Server running on port ${PORT}`);
        console.log(`📊 Dashboard: http://localhost:${PORT}`);
        console.log(`🔗 Webhook endpoint: http://localhost:${PORT}/webhook/sms`);
        console.log(`\n💡 For local development, use ngrok to expose your webhook:`);
        console.log(`   ngrok http ${PORT}`);
        console.log(`   Then update WEBHOOK_URL in .env with the ngrok URL\n`);
    });
}

// Handle graceful shutdown
process.on('SIGINT', async () => {
    console.log('\n👋 Shutting down gracefully...');
    await platform.logout();
    process.exit(0);
});

// Start the application
startServer();
